 pour tester la solution vous devez  importer la base de donner nomée database_test situer a la racine du projet
dans mariaDb 
 ouvrire le projet a la racine dans un terminale  verifier que vous avez une bonne connexion internet puis executer la commande 
npm i  --save
pour telecharger les paquets en suite executer la commande npm start
 ouvrer le lien   http://localhost:3001  dans le navigateur